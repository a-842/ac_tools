# ajtc_tools
This is a module with tools that I have coded and may be useful to me or others in the future, below is a list of the included tools.
## searching
 - Binary Search
## sorting
 - Bubble Sort
 - Merge Sort
 - Quick Sort
 - Insertion Sort
 - Bogo Sort
